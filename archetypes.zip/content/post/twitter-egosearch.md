+++
banner = "https://lh5.googleusercontent.com/YTA2cIAjg42nhqfg1mxpI--dhxWWDY13oOwJjqzEi501oZVgNqf9Aqh9C8M=w2400"
categories = ["Twitter"]
date = "2017-04-08"
description = ""
images = []
menu = ""
tags = ["Twitter", "エゴサ"]
title = "Twitterエゴサ用検索コマンド"
+++


# コマンド
    [エゴサしたいワード] -from:[自分のID] filter:follows


<!--more-->



## 意味
[エゴサしたいワード] → 単純に検索ワード

-from:[自分のID] → 検索結果から自分のツイートを除く。複数指定可、サブ垢とかで同じ名前を入れてる時などに使える。

filter:follows → フォロワーの中から検索する、フォロー外まで検索したいときは消す。(公式ページに乗ってないため稀にこれのために検索結果が0になる時がある)

### 例
    うにゃ -from:unya_2 -from:unya_3 filter:follows
    