+++
title = "How to add pages to the menu"
date = "2015-10-02T21:49:20+02:00"
tags = ["golang", "programming", "theme", "hugo"]
categories = ["programming"]
menu = "main"
banner = "banners/placeholder.png"
+++

I'm a linked post in the menu. You can add other posts by adding the following line to the frontmatter:

    menu = "main"