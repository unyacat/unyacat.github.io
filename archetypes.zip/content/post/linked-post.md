+++
title = "How to add pages to the menu"
date = "2015-10-05"
tags = ["golang", "programming", "theme", "hugo"]
categories = ["programming"]
menu = ""
banner = "banners/placeholder.png"
draft = "true"
+++

I'm a linked post in the menu. You can add other posts by adding the following line to the frontmatter:
    
    menu = "main"
## もしかすると
こうなのかもしれません